package to.be.defined.productionChart.demo;

import javafx.beans.property.*;

public class PresentationModel {
    private final DoubleProperty prod15 = new SimpleDoubleProperty(4100);
    private final DoubleProperty prod16 = new SimpleDoubleProperty(4400);
    private final DoubleProperty prod17 = new SimpleDoubleProperty(5100);
    private final DoubleProperty prod18 = new SimpleDoubleProperty(4250);

    public double getProd15() {
        return prod15.get();
    }

    public DoubleProperty prod15Property() {
        return prod15;
    }

    public void setProd15(double prod15) {
        this.prod15.set(prod15);
    }

    public double getProd16() {
        return prod16.get();
    }

    public DoubleProperty prod16Property() {
        return prod16;
    }

    public void setProd16(double prod16) {
        this.prod16.set(prod16);
    }

    public double getProd17() {
        return prod17.get();
    }

    public DoubleProperty prod17Property() {
        return prod17;
    }

    public void setProd17(double prod17) {
        this.prod17.set(prod17);
    }

    public double getProd18() {
        return prod18.get();
    }

    public DoubleProperty prod18Property() {
        return prod18;
    }

    public void setProd18(double prod18) {
        this.prod18.set(prod18);
    }
}
