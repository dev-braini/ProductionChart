package to.be.defined.productionChart.demo;

import to.be.defined.productionChart.ProductionChart;
import to.be.defined.productionChart.TextfieldProduction;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.text.Font;


class DemoPane extends VBox {
    // business controls
    private TextfieldProduction production2015, production2016, production2017, production2018;
    private Label title, production2015Label, production2016Label, production2017Label, production2018Label;

    // custom control
    private ProductionChart customControl;
    private PresentationModel pm;

    DemoPane(PresentationModel pm) {
        this.pm = pm;

        initializeControls();
        setStyles();
        layoutControls();
        setupBindings();
    }

    private void initializeControls() {
        customControl = new ProductionChart();

        production2015 = new TextfieldProduction();
        production2016 = new TextfieldProduction();
        production2017 = new TextfieldProduction();
        production2018 = new TextfieldProduction();

        title = new Label("Produktion 2015 - 2018");
        production2015Label = new Label("Produktion 2015 (MWh)");
        production2016Label = new Label("Produktion 2016 (MWh)");
        production2017Label = new Label("Produktion 2017 (MWh)");
        production2018Label = new Label("Produktion 2018 (MWh)");
    }
    private void setStyles() {
        Insets paddingLabel = new Insets(10, 13, 11, 15);
        Insets paddingTextfield = new Insets(0, 15, 0, 0);
        production2015.setPadding(paddingTextfield);
        production2016.setPadding(paddingTextfield);
        production2017.setPadding(paddingTextfield);
        production2018.setPadding(paddingTextfield);

        HBox.setHgrow(production2015, Priority.ALWAYS);
        HBox.setHgrow(production2016, Priority.ALWAYS);
        HBox.setHgrow(production2017, Priority.ALWAYS);
        HBox.setHgrow(production2018, Priority.ALWAYS);

        production2015Label.setPadding(paddingLabel);
        production2016Label.setPadding(paddingLabel);
        production2017Label.setPadding(paddingLabel);
        production2018Label.setPadding(paddingLabel);
        title.setFont(new Font(27));
        title.setPadding(new Insets(14, 15, 15, 15));
        VBox.setVgrow(customControl, Priority.ALWAYS);
    }

    private void layoutControls() {
        HBox hbox1 = new HBox(production2015Label, production2015, production2017Label, production2017);
        HBox hbox2 = new HBox(production2016Label, production2016, production2018Label, production2018);

        hbox1.setPadding(new Insets(10, 0, 0, 0));
        hbox2.setPadding(new Insets(0, 0, 12, 0));

        getChildren().addAll(title, customControl, hbox1, hbox2);
    }

    private void setupBindings() {
        // binding business control
        production2015.bind(
                production2015,
                production2016,
                production2017,
                production2018,
                pm.prod15Property(),
                pm.prod16Property(),
                pm.prod17Property(),
                pm.prod18Property()
        );

        // binding custom control
        customControl.bind(pm.prod15Property(), pm.prod16Property(), pm.prod17Property(), pm.prod18Property());
    }

}
