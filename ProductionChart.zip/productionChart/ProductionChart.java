package to.be.defined.productionChart;

import javafx.beans.property.*;
import javafx.geometry.*;
import javafx.scene.control.Label;
import javafx.scene.shape.Polygon;
import javafx.scene.text.*;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.util.StringConverter;
import javafx.util.converter.NumberStringConverter;
import java.util.*;
import java.util.function.UnaryOperator;

import static javafx.scene.input.KeyCode.*;

/**
 * CustomControl ProductionChart
 *
 * Dieses CustomControl stellt ein Liniendiagramm von 2015 - 2018 dar.
 * - Die Werte können per direkter Eingabe (Klick auf Wert) oder per Drag&Drop eingestellt werden.
 * - Während direkter Eingabe kann mit den Tasten Pfeil rauf und runter der Wert geändert werden.
 * - Die Skala wird initial automatisch sinnvoll berechnet und sie passt sich dynamisch an.
 * - Per Doppelklick kann das Layout von umgestellt werden.
 * - Die Linien sind grün oder rot eingefärbt je nach dem ob die Produktion gestiefen oder gesunken ist.
 *
 * @author Markus Winter
 */
public class ProductionChart extends Region {
    private static final String  ICO_CHANGE_VIEW = "\uf079";
    public static final Locale   CH              = new Locale("de", "CH");

    private static final double  ARTBOARD_WIDTH  = 620;
    private static final double  ARTBOARD_HEIGHT = 210;

    private static final double  ASPECT_RATIO    = ARTBOARD_WIDTH / ARTBOARD_HEIGHT;

    private static final double  MINIMUM_WIDTH   = 250;
    private static final double  MINIMUM_HEIGHT  = MINIMUM_WIDTH / ASPECT_RATIO;

    private static final double  MAXIMUM_WIDTH   = 4096;

    private static final double  PADDING_TOP     = 34;
    private static final double  PADDING_BOTTOM  = 57;
    private static final double  PADDING         = PADDING_TOP+PADDING_BOTTOM;

    private static double        globalStep      = 0;
    private static double        globalMaxValue  = 0;

    private final ArrayList<Circle>     circles              = new ArrayList<>();
    private final ArrayList<Polygon>    windWheels           = new ArrayList<>();
    private final ArrayList<Line>       lines                = new ArrayList<>();
    private final ArrayList<Text>       texts                = new ArrayList<>();
    private final ArrayList<TextField>  values               = new ArrayList<>();


    private final SimpleDoubleProperty  productionValue_2015 = new SimpleDoubleProperty();
    private final SimpleDoubleProperty  productionValue_2016 = new SimpleDoubleProperty();
    private final SimpleDoubleProperty  productionValue_2017 = new SimpleDoubleProperty();
    private final SimpleDoubleProperty  productionValue_2018 = new SimpleDoubleProperty();

    private final SimpleBooleanProperty showWindWheels       = new SimpleBooleanProperty(true);

    private Pane  drawingPane;
    private Label changeView;

    public ProductionChart() {
        initializeSelf();
        initializeParts();
        initializeDrawingPane();
        layoutParts();
        setupEventHandlers();
        setupValueChangeListeners();
        setupBindings();
    }

    private void initializeSelf() {
        loadFonts("fonts/fontawesome-webfont.ttf");
        addStylesheetFiles("css/productionChart.css");
        getStyleClass().add("production-chart");
    }

    private void initializeParts() {
        // Fixe Paramaeter
        double baseDistance        = ARTBOARD_WIDTH * 0.1;
        double yearWidth           = ARTBOARD_WIDTH * 0.8 / 3.6;

        double groundLineDistance  = 30;
        double yearBottomDistance  =  9;
        double circleSize          =  4.5;

        double year_2015      = baseDistance+yearWidth * 0.0;
        double year_2015_line = baseDistance+yearWidth * 0.6;
        double year_2016      = baseDistance+yearWidth * 1.2;
        double year_2016_line = baseDistance+yearWidth * 1.8;
        double year_2017      = baseDistance+yearWidth * 2.4;
        double year_2017_line = baseDistance+yearWidth * 3.0;
        double year_2018      = baseDistance+yearWidth * 3.6;

        changeView = new Label(ICO_CHANGE_VIEW);
        changeView.getStyleClass().add("change-view");
        changeView.setLayoutX(ARTBOARD_WIDTH-22);
        changeView.setLayoutY(-10);

        // Wert-Punkte
        circles.add(createCircle(year_2015, circleSize, "year-circle"));
        circles.add(createCircle(year_2015, circleSize*2.6, "year-circle-effect"));
        circles.add(createCircle(year_2016, circleSize, "year-circle"));
        circles.add(createCircle(year_2016, circleSize*2.6, "year-circle-effect"));
        circles.add(createCircle(year_2017, circleSize, "year-circle"));
        circles.add(createCircle(year_2017, circleSize*2.6, "year-circle-effect"));
        circles.add(createCircle(year_2018, circleSize, "year-circle"));
        circles.add(createCircle(year_2018, circleSize*2.6, "year-circle-effect"));

        // Werte
        values.add(createTextField(year_2015, "textfield-value"));
        values.add(createTextField(year_2016, "textfield-value"));
        values.add(createTextField(year_2017, "textfield-value"));
        values.add(createTextField(year_2018, "textfield-value"));

        // Windräder
        windWheels.add(createWindWheel(year_2015, "wind-wheel"));
        windWheels.add(createWindWheel(year_2016, "wind-wheel"));
        windWheels.add(createWindWheel(year_2017, "wind-wheel"));
        windWheels.add(createWindWheel(year_2018, "wind-wheel"));

        // Jahre
        texts.add(createCenteredText(year_2015, ARTBOARD_HEIGHT-yearBottomDistance, "2015", "text-year"));
        texts.add(createCenteredText(year_2016, ARTBOARD_HEIGHT-yearBottomDistance, "2016", "text-year"));
        texts.add(createCenteredText(year_2017, ARTBOARD_HEIGHT-yearBottomDistance, "2017", "text-year"));
        texts.add(createCenteredText(year_2018, ARTBOARD_HEIGHT-yearBottomDistance, "2018", "text-year"));

        // Windwheel Linien
        lines.add(createLine(year_2015, ARTBOARD_HEIGHT-groundLineDistance, year_2015, 0, "wind-wheel-line"));
        lines.add(createLine(year_2016, ARTBOARD_HEIGHT-groundLineDistance, year_2016, 0, "wind-wheel-line"));
        lines.add(createLine(year_2017, ARTBOARD_HEIGHT-groundLineDistance, year_2017, 0, "wind-wheel-line"));
        lines.add(createLine(year_2018, ARTBOARD_HEIGHT-groundLineDistance, year_2018, 0, "wind-wheel-line"));

        // Vertikale Linien
        lines.add(createLine(year_2015_line, 0, year_2015_line, ARTBOARD_HEIGHT, "line-vertical"));
        lines.add(createLine(year_2016_line, 0, year_2016_line, ARTBOARD_HEIGHT, "line-vertical"));
        lines.add(createLine(year_2017_line, 0, year_2017_line, ARTBOARD_HEIGHT, "line-vertical"));

        // Verbindungs-Linien
        lines.add(createLine(year_2015, 0, year_2016, 0, "line-connection"));
        lines.add(createLine(year_2016, 0, year_2017, 0, "line-connection"));
        lines.add(createLine(year_2017, 0, year_2018, 0, "line-connection"));

        // Grundlinie (horizontal)
        lines.add(createLine(0, ARTBOARD_HEIGHT-groundLineDistance, ARTBOARD_WIDTH, ARTBOARD_HEIGHT-groundLineDistance, "line-ground"));
    }

    private void initializeDrawingPane() {
        drawingPane = new Pane();
        drawingPane.getStyleClass().add("drawing-pane");
        drawingPane.setMaxSize(ARTBOARD_WIDTH,  ARTBOARD_HEIGHT);
        drawingPane.setMinSize(ARTBOARD_WIDTH,  ARTBOARD_HEIGHT);
        drawingPane.setPrefSize(ARTBOARD_WIDTH, ARTBOARD_HEIGHT);
    }

    private void layoutParts() {
        drawingPane.getChildren().addAll(lines);
        drawingPane.getChildren().addAll(texts);
        drawingPane.getChildren().addAll(values);
        drawingPane.getChildren().addAll(windWheels);
        drawingPane.getChildren().addAll(circles);
        drawingPane.getChildren().add(changeView);

        getChildren().add(drawingPane);
    }

    private void setupEventHandlers() {
        // Drag & Drop
        circles.get(1).setOnMousePressed(event -> setGlobalValues(circles.get(1)));
        circles.get(3).setOnMousePressed(event -> setGlobalValues(circles.get(3)));
        circles.get(5).setOnMousePressed(event -> setGlobalValues(circles.get(5)));
        circles.get(7).setOnMousePressed(event -> setGlobalValues(circles.get(7)));

        circles.get(1).setOnMouseDragged(event -> setProductionValue_2015(calcPositionFromMousePos(event.getY())) );
        circles.get(3).setOnMouseDragged(event -> setProductionValue_2016(calcPositionFromMousePos(event.getY())) );
        circles.get(5).setOnMouseDragged(event -> setProductionValue_2017(calcPositionFromMousePos(event.getY())) );
        circles.get(7).setOnMouseDragged(event -> setProductionValue_2018(calcPositionFromMousePos(event.getY())) );

        circles.get(1).setOnMouseReleased(event -> circles.get(1).getStyleClass().remove("active"));
        circles.get(3).setOnMouseReleased(event -> circles.get(3).getStyleClass().remove("active"));
        circles.get(5).setOnMouseReleased(event -> circles.get(5).getStyleClass().remove("active"));
        circles.get(7).setOnMouseReleased(event -> circles.get(7).getStyleClass().remove("active"));

        // UP & DOWN keys
        values.get(0).setOnKeyPressed(event -> handleArrowKeys(event, productionValue_2015Property()));
        values.get(1).setOnKeyPressed(event -> handleArrowKeys(event, productionValue_2016Property()));
        values.get(2).setOnKeyPressed(event -> handleArrowKeys(event, productionValue_2017Property()));
        values.get(3).setOnKeyPressed(event -> handleArrowKeys(event, productionValue_2018Property()));

        // Doubleclick: Windwheels visible or not
        drawingPane.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2 && !event.isConsumed()) {
                event.consume();
                setShowWindWheels(!isShowWindWheels());
            }
        });

        // click on changeview icon
        changeView.setOnMouseClicked(event -> setShowWindWheels(!isShowWindWheels()));
    }

    private void setupValueChangeListeners() {
        productionValue_2015Property().addListener((observable, oldValue, newValue) -> updateUI());
        productionValue_2016Property().addListener((observable, oldValue, newValue) -> updateUI());
        productionValue_2017Property().addListener((observable, oldValue, newValue) -> updateUI());
        productionValue_2018Property().addListener((observable, oldValue, newValue) -> updateUI());
        showWindWheelsProperty()      .addListener((observable, oldValue, newValue) -> updateUI());
    }

    private void setupBindings() {
        StringConverter<Number> sc = new NumberStringConverter(CH, "#0 MWh");

        values.get(0).textProperty().bindBidirectional(productionValue_2015Property(), sc);
        values.get(1).textProperty().bindBidirectional(productionValue_2016Property(), sc);
        values.get(2).textProperty().bindBidirectional(productionValue_2017Property(), sc);
        values.get(3).textProperty().bindBidirectional(productionValue_2018Property(), sc);

    }

    private void setUIValues(Circle circle1, Circle circle2, Polygon windWheel, Line windWheelLine, Line lineBegin, Line lineEnd, TextField value, double newPosY) {
        double circleValueDistance = (isShowWindWheels()) ? 61 : 46;
        if(newPosY-PADDING_TOP <= (ARTBOARD_HEIGHT-PADDING)/4) circleValueDistance /= (isShowWindWheels()) ? -2.3 : -1.8;

        circle1      .setCenterY(newPosY);
        circle2      .setCenterY(newPosY);
        windWheel    .setLayoutY(newPosY);
        windWheel    .setVisible(isShowWindWheels());
        value        .setLayoutY(newPosY-circleValueDistance);
        windWheelLine.setEndY(newPosY);
        windWheelLine.setVisible(isShowWindWheels());

        if(lineBegin != null) lineBegin.setEndY(newPosY);
        if(lineEnd != null)   lineEnd.setStartY(newPosY);
    }

    private void updateUI(){
        // 2015
        setUIValues(
                circles.get(0),
                circles.get(1),
                windWheels.get(0),
                lines.get(0),
                null,
                lines.get(7),
                values.get(0),
                calcPositionFromValue(getProductionValue_2015())
        );

        // 2016
        setUIValues(
                circles.get(2),
                circles.get(3),
                windWheels.get(1),
                lines.get(1),
                lines.get(7),
                lines.get(8),
                values.get(1),
                calcPositionFromValue(getProductionValue_2016())
        );

        // 2017
        setUIValues(
                circles.get(4),
                circles.get(5),
                windWheels.get(2),
                lines.get(2),
                lines.get(8),
                lines.get(9),
                values.get(2),
                calcPositionFromValue(getProductionValue_2017())
        );

        // 2018
        setUIValues(
                circles.get(6),
                circles.get(7),
                windWheels.get(3),
                lines.get(3),
                lines.get(9),
                null,
                values.get(3),
                calcPositionFromValue(getProductionValue_2018())
        );

        // set line colors
        lines.get(7).getStyleClass().retainAll("line-connection");
        lines.get(7).getStyleClass().add((lines.get(7).getStartY() < lines.get(7).getEndY()) ? "line-red" : "line-green");

        lines.get(8).getStyleClass().retainAll("line-connection");
        lines.get(8).getStyleClass().add((lines.get(8).getStartY() < lines.get(8).getEndY()) ? "line-red" : "line-green");

        lines.get(9).getStyleClass().retainAll("line-connection");
        lines.get(9).getStyleClass().add((lines.get(9).getStartY() < lines.get(9).getEndY()) ? "line-red" : "line-green");
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        resize();
    }

    private void resize() {
        Insets padding         = getPadding();
        double availableWidth  = getWidth() - padding.getLeft() - padding.getRight();
        double availableHeight = getHeight() - padding.getTop() - padding.getBottom();

        double width = Math.max(Math.min(Math.min(availableWidth, availableHeight * ASPECT_RATIO), MAXIMUM_WIDTH), MINIMUM_WIDTH);

        double scalingFactor = width / ARTBOARD_WIDTH;

        if (availableWidth > 0 && availableHeight > 0) {
            relocateDrawingPaneCentered();
            drawingPane.setScaleX(scalingFactor);
            drawingPane.setScaleY(scalingFactor);
        }
    }

    private void relocateDrawingPaneCentered() {
        drawingPane.relocate((getWidth() - ARTBOARD_WIDTH) * 0.5, (getHeight() - ARTBOARD_HEIGHT) * 0.5);
    }

    // Sammlung nuetzlicher Funktionen
    public void bind(DoubleProperty value2015, DoubleProperty value2016, DoubleProperty value2017, DoubleProperty value2018) {
        this.productionValue_2015Property().bindBidirectional(value2015);
        this.productionValue_2016Property().bindBidirectional(value2016);
        this.productionValue_2017Property().bindBidirectional(value2017);
        this.productionValue_2018Property().bindBidirectional(value2018);
    }

    private void setGlobalValues(Circle el) {
        double[] values = new double[]{ getProductionValue_2015(), getProductionValue_2016(), getProductionValue_2017(), getProductionValue_2018() };
        double minValue = getMinValue(values);
        double maxValue = getMaxValue(values);
        double viewPort = ARTBOARD_HEIGHT-PADDING;

        globalStep      = (maxValue-minValue)/viewPort;
        globalMaxValue  = maxValue;

        if(globalStep <= 0) globalStep = 1;

        el.getStyleClass().add("active");
    }

    private Circle createCircle(double x, double size, String cssClass){
        Circle c = new Circle(x, 0, size);
        c.getStyleClass().add(cssClass);

        return c;
    }

    private Line createLine(double startX, double startY, double endX, double endY, String cssClass){
        Line l = new Line(startX, startY, endX, endY);
        l.getStyleClass().add(cssClass);

        return l;
    }

    private TextField createTextField(double x, String cssClass){
        double width = 72;
        TextField tf = new TextField();

        UnaryOperator<TextFormatter.Change> filter = change -> {
            String text = change.getControlNewText();

            // prevent editing the unit
            if (change.getCaretPosition() <= text.length()-4 || change.getAnchor() <= text.length()-4) {
                if(text.trim().equals("MWh")) change.setText("0");
                if (text.matches("[0-9]{0,6}+ MWh$")) return change;
            }

            return null;
        };

        tf.setMinWidth(width);
        tf.setMaxWidth(width);
        tf.setLayoutX(x-width/2);
        tf.setTextFormatter(new TextFormatter<>(filter));
        tf.setFocusTraversable(false);
        tf.getStyleClass().add(cssClass);

        return tf;
    }

    private Polygon createWindWheel(double startX, String cssClass) {
        Polygon windWheel = new Polygon();
        windWheel.getPoints().addAll(
                startX,      1.0,
                startX- 9,   3.0,
                startX-36,  21.0,
                startX-35,  22.0,
                startX- 6,   8.0,
                startX,      1.0,

                startX+ 2,   2.0,
                startX+ 6,   8.0,
                startX+36,  22.0,
                startX+36,  21.0,
                startX+ 9,   3.0,
                startX,      1.0,

                startX,     -2.0,
                startX+ 3,  -8.0,
                startX,    -41.0,
                startX- 1, -41.0,
                startX- 3,  -8.0,
                startX,      1.0
        );
        windWheel.setScaleX(0.89);
        windWheel.setScaleY(0.89);
        windWheel.getStyleClass().add(cssClass);

        return windWheel;
    }

    private double calcPositionFromValue(double value) {
        double[] values        = new double[]{ getProductionValue_2015(), getProductionValue_2016(), getProductionValue_2017(), getProductionValue_2018() };
        double minValue        = getMinValue(values);
        double maxValue        = getMaxValue(values);
        double valueDifference = Math.round((maxValue-minValue) * 100.0) / 100.0;
        double viewPort        = ARTBOARD_HEIGHT-PADDING;
        double step            = viewPort/valueDifference;

        if(valueDifference == 0) return ARTBOARD_HEIGHT-PADDING_BOTTOM;

        return (ARTBOARD_HEIGHT-(value-minValue)*step)-PADDING_BOTTOM;
    }

    private double calcPositionFromMousePos(double value) {
        double newPosY = globalMaxValue-(value-PADDING_TOP)*globalStep;

        return (newPosY < 0) ? 0 : newPosY;
    }

    private double getMaxValue(double[] values) {
        double max = Double.MIN_VALUE;
        for (double value : values) max = Math.max(max, value);

        return max;
    }

    private double getMinValue(double[] values) {
        double min = Double.MAX_VALUE;
        for (double value : values) min = Math.min(min, value);

        return min;
    }

    private void handleArrowKeys(KeyEvent event, SimpleDoubleProperty source) {
        KeyCode key   = event.getCode();
        boolean shift = event.isShiftDown();
        boolean ctrl  = event.isControlDown();
        boolean alt   = event.isAltDown();
        double  addValue;

        if(key == UP || key == DOWN) {
            if(shift && ctrl && alt) addValue = 1000;
            else if(shift && ctrl)   addValue = 100;
            else if(shift)           addValue = 10;
            else                     addValue = 1;

            if(key == DOWN) addValue *= -1;

            source.set(source.get() + addValue);
        }
    }

    public void loadFonts(String... font){
        for(String f : font){
            Font.loadFont(getClass().getResourceAsStream(f), 0);
        }
    }

    private void addStylesheetFiles(String... stylesheetFile){
        for(String file : stylesheetFile){
            String stylesheet = getClass().getResource(file).toExternalForm();
            getStylesheets().add(stylesheet);
        }
    }

    /**
     * Erzeugt eine Text-Instanz mit dem angegebenen Zentrum.
     * Der Text bleibt zentriert auch wenn der angezeigte Text sich aendert.
     *
     * @param cx x-Position des Zentrumspunkt des Textes
     * @param cy y-Position des Zentrumspunkt des Textes
     * @param text darzustellender Text
     * @param styleClass mit dieser StyleClass kann der erzeugte Text via css gestyled werden
     * @return Text
     */
    private Text createCenteredText(double cx, double cy, String text, String styleClass) {
        double width = cx > ARTBOARD_WIDTH * 0.5 ? ((ARTBOARD_WIDTH - cx) * 2.0) : cx * 2.0;
        Text t = new Text(text);

        t.getStyleClass().add(styleClass);
        t.setTextOrigin(VPos.CENTER);
        t.setTextAlignment(TextAlignment.CENTER);
        t.setWrappingWidth(width);
        t.setBoundsType(TextBoundsType.VISUAL);
        t.setY(cy);
        t.setX(cx - (width / 2.0));

        return t;
    }

    // compute sizes
    @Override
    protected double computeMinWidth(double height) {
        Insets padding           = getPadding();
        double horizontalPadding = padding.getLeft() + padding.getRight();

        return MINIMUM_WIDTH + horizontalPadding;
    }

    @Override
    protected double computeMinHeight(double width) {
        Insets padding         = getPadding();
        double verticalPadding = padding.getTop() + padding.getBottom();

        return MINIMUM_HEIGHT + verticalPadding;
    }

    @Override
    protected double computePrefWidth(double height) {
        Insets padding           = getPadding();
        double horizontalPadding = padding.getLeft() + padding.getRight();

        return ARTBOARD_WIDTH + horizontalPadding;
    }

    @Override
    protected double computePrefHeight(double width) {
        Insets padding         = getPadding();
        double verticalPadding = padding.getTop() + padding.getBottom();

        return ARTBOARD_HEIGHT + verticalPadding;
    }

    // Getter and Setter)
    public double               getProductionValue_2015()                            { return productionValue_2015.get(); }
    public SimpleDoubleProperty productionValue_2015Property()                       { return productionValue_2015; }
    public void                 setProductionValue_2015(double productionValue_2015) { this.productionValue_2015.set(productionValue_2015); }

    public double               getProductionValue_2016()                            { return productionValue_2016.get(); }
    public SimpleDoubleProperty productionValue_2016Property()                       { return productionValue_2016; }
    public void                 setProductionValue_2016(double productionValue_2016) { this.productionValue_2016.set(productionValue_2016); }

    public double               getProductionValue_2017()                            { return productionValue_2017.get(); }
    public SimpleDoubleProperty productionValue_2017Property()                       { return productionValue_2017; }
    public void                 setProductionValue_2017(double productionValue_2017) { this.productionValue_2017.set(productionValue_2017); }

    public double               getProductionValue_2018()                            { return productionValue_2018.get(); }
    public                      SimpleDoubleProperty productionValue_2018Property()  { return productionValue_2018; }
    public void                 setProductionValue_2018(double productionValue_2018) { this.productionValue_2018.set(productionValue_2018); }

    public boolean              isShowWindWheels()                                   { return showWindWheels.get(); }
    public                      SimpleBooleanProperty showWindWheelsProperty()       { return showWindWheels; }
    public void                 setShowWindWheels(boolean showWindWheels)            { this.showWindWheels.set(showWindWheels); }
}
