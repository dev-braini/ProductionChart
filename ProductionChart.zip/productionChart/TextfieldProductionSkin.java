package to.be.defined.productionChart;

import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.SkinBase;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;
import javafx.util.converter.NumberStringConverter;

import java.util.function.UnaryOperator;

/**
 * Default-Skin für BusinessControl TextfieldProduction
 *
 * @author Markus Winter
 */
class TextfieldProductionSkin extends SkinBase<TextfieldProduction> {
    private static final String ANGLE_DOWN = "\uf107";
    private static final String ANGLE_UP   = "\uf106";

    private static final String STYLE_CSS = "css/textfieldProduction.css";

    // all parts
    private TextField       textfield;
    private Popup           popup;
    private ProductionChart chart;
    private Button          chooserButton;

    private StackPane       drawingPane;

    TextfieldProductionSkin(TextfieldProduction control) {
        super(control);
        initializeSelf();
        initializeParts();
        layoutParts();
        setupEventHandlers();
        setupValueChangeListeners();
        setupBindings();
    }

    private void initializeSelf() {
        getSkinnable().loadFonts("fonts/fontawesome-webfont.ttf");
        getSkinnable().addStylesheetFiles(STYLE_CSS);
    }

    private void initializeParts() {
        textfield = new TextField();

        chooserButton = new Button(ANGLE_DOWN);
        chooserButton.getStyleClass().add("chooser-button");

        chart = new ProductionChart();

        popup = new Popup();
        popup.getContent().addAll(chart);

        drawingPane = new StackPane();
        drawingPane.getStyleClass().add("drawing-pane");
    }

    private void layoutParts() {
        StackPane.setAlignment(chooserButton, Pos.CENTER_RIGHT);
        drawingPane.getChildren().addAll(textfield, chooserButton);

        StackPane.setAlignment(textfield, Pos.CENTER_LEFT);

        getChildren().add(drawingPane);
    }

    private void setupEventHandlers() {
        chooserButton.setOnAction(event -> {
            if (popup.isShowing()) {
                popup.hide();
                chooserButton.getStyleClass().remove("active");
            } else {
                popup.show(textfield.getScene().getWindow());
                chooserButton.getStyleClass().add("active");
            }
        });

        popup.setOnHidden(event -> chooserButton.setText(ANGLE_DOWN));

        popup.setOnShown(event -> {
            chooserButton.setText(ANGLE_UP);
            Point2D location = textfield.localToScreen(
                    textfield.getWidth()  - chart.getPrefWidth() - 3,
                    textfield.getHeight() -3
            );

            popup.setX(location.getX());
            popup.setY(location.getY());
        });
    }

    private void setupValueChangeListeners() {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String text = change.getControlNewText();

            if (text.matches("[0-9.]{0,9}$")) return change;

            return null;
        };

        textfield.setTextFormatter(new TextFormatter<>(filter));
    }

    private void setupBindings() {
        textfield.textProperty().bindBidirectional(getSkinnable().productionValueProperty(), new NumberStringConverter(ProductionChart.CH, "#0.00"));

        chart.productionValue_2015Property().bindBidirectional(getSkinnable().productionValue_2015Property());
        chart.productionValue_2016Property().bindBidirectional(getSkinnable().productionValue_2016Property());
        chart.productionValue_2017Property().bindBidirectional(getSkinnable().productionValue_2017Property());
        chart.productionValue_2018Property().bindBidirectional(getSkinnable().productionValue_2018Property());
    }
}
