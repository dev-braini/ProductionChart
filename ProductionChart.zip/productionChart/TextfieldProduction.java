package to.be.defined.productionChart;

import javafx.beans.property.*;
import javafx.scene.control.Control;
import javafx.scene.control.Skin;
import javafx.scene.text.Font;

/**
 * BusinessControl TextfieldProduction
 *
 * Dieses BusinessCustomControl stellt nebst einem normalen Textfield im DefaultSkin einen Dropdown-Pfeil dar.
 * Es öffnet sich ein Popup indem das CustomControl ProductionChart dargestellt wird.
 * Die Eingaben in das Textfeld werden rudimentär geprüft.
 *
 * @author Markus Winter
 */
public class TextfieldProduction extends Control {
    private final DoubleProperty productionValue = new SimpleDoubleProperty();
    private final DoubleProperty productionValue_2015 = new SimpleDoubleProperty();
    private final DoubleProperty productionValue_2016 = new SimpleDoubleProperty();
    private final DoubleProperty productionValue_2017 = new SimpleDoubleProperty();
    private final DoubleProperty productionValue_2018 = new SimpleDoubleProperty();

    public TextfieldProduction() {
        initializeSelf();
    }

    @Override
    protected Skin<?> createDefaultSkin() {
        return new TextfieldProductionSkin(this);
    }

    private void initializeSelf() {
         getStyleClass().add("textfield-production");
    }

    public void addStylesheetFiles(String... stylesheetFile){
        for(String file : stylesheetFile){
            String stylesheet = getClass().getResource(file).toExternalForm();
            getStylesheets().add(stylesheet);
        }
    }

    public void loadFonts(String... font){
        for(String f : font){
            System.out.println("MW DEBUG" + f);
            Font.loadFont(getClass().getResourceAsStream(f), 0);
        }
    }

    // helper method for binding
    private void bindHelper(DoubleProperty value, DoubleProperty value2015, DoubleProperty value2016, DoubleProperty value2017, DoubleProperty value2018) {
        this.productionValueProperty().bindBidirectional(value);
        this.productionValue_2015Property().bindBidirectional(value2015);
        this.productionValue_2016Property().bindBidirectional(value2016);
        this.productionValue_2017Property().bindBidirectional(value2017);
        this.productionValue_2018Property().bindBidirectional(value2018);
    }

    // bind all fields (2015-2018)
    public void bind(TextfieldProduction production2015, TextfieldProduction production2016, TextfieldProduction production2017, TextfieldProduction production2018, DoubleProperty productionValue_2015Property, DoubleProperty productionValue_2016Property, DoubleProperty productionValue_2017Property, DoubleProperty productionValue_2018Property) {
        production2015.bindHelper(productionValue_2015Property, productionValue_2015Property, productionValue_2016Property, productionValue_2017Property, productionValue_2018Property);
        production2016.bindHelper(productionValue_2016Property, productionValue_2015Property, productionValue_2016Property, productionValue_2017Property, productionValue_2018Property);
        production2017.bindHelper(productionValue_2017Property, productionValue_2015Property, productionValue_2016Property, productionValue_2017Property, productionValue_2018Property);
        production2018.bindHelper(productionValue_2018Property, productionValue_2015Property, productionValue_2016Property, productionValue_2017Property, productionValue_2018Property);
    }

    // bind only one field
    public void bind(TextfieldProduction production, DoubleProperty productionValue_2015Property, DoubleProperty productionValue_2016Property, DoubleProperty productionValue_2017Property, DoubleProperty productionValue_2018Property) {
        production.bindHelper(productionValue_2015Property, productionValue_2015Property, productionValue_2016Property, productionValue_2017Property, productionValue_2018Property);
    }

    // getter and setter
    public double getProductionValue() {
        return productionValue.get();
    }

    public DoubleProperty productionValueProperty() {
        return productionValue;
    }

    public void setProductionValue(double productionValue) {
        this.productionValue.set(productionValue);
    }

    public double getProductionValue_2015() {
        return productionValue_2015.get();
    }

    public DoubleProperty productionValue_2015Property() {
        return productionValue_2015;
    }

    public void setProductionValue_2015(double productionValue_2015) {
        this.productionValue_2015.set(productionValue_2015);
    }

    public double getProductionValue_2016() {
        return productionValue_2016.get();
    }

    public DoubleProperty productionValue_2016Property() {
        return productionValue_2016;
    }

    public void setProductionValue_2016(double productionValue_2016) {
        this.productionValue_2016.set(productionValue_2016);
    }

    public double getProductionValue_2017() {
        return productionValue_2017.get();
    }

    public DoubleProperty productionValue_2017Property() {
        return productionValue_2017;
    }

    public void setProductionValue_2017(double productionValue_2017) {
        this.productionValue_2017.set(productionValue_2017);
    }

    public double getProductionValue_2018() {
        return productionValue_2018.get();
    }

    public DoubleProperty productionValue_2018Property() {
        return productionValue_2018;
    }

    public void setProductionValue_2018(double productionValue_2018) {
        this.productionValue_2018.set(productionValue_2018);
    }
}
